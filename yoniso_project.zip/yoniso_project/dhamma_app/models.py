from django.db import models

class Article(models.Model):
    title = models.CharField(max_length=300, verbose_name="စာပေခေါင်းစဉ်")
    author = models.CharField(max_length=200, default="ဓမ္မဒါန", verbose_name="ရေးသား/ဟောကြားသူ")
    summary = models.CharField(max_length=500, verbose_name="အကျဉ်းချုပ် ရှင်းလင်းချက်")
    content = models.TextField(verbose_name="တရားစာပေ အကြောင်းအရာ")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="ဖန်တီးသည့်ရက်စွဲ")

    def __str__(self):
        return self.title
