// js/script.js

// Dark Mode Switch ဖွင့်/ပိတ် ပြုလုပ်ပေးမည့် Function
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    
    // ဖုန်းထဲတွင် Mode ကို မှတ်ထားပေးရန်
    if (document.body.classList.contains('dark-mode')) {
        localStorage.setItem('theme', 'dark');
    } else {
        localStorage.setItem('theme', 'light');
    }
}

// စာမျက်နှာ Refresh ဖြစ်ချိန်တွင် ယခင် ရွေးထားခဲ့သော Theme အဟောင်းကို ပြန်ဖွင့်ပေးခြင်း
document.addEventListener("DOMContentLoaded", function() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
    }
});

// စာလုံးဆိုဒ် ပြင်မည့် Function
let currentFontSize = 19;
function changeFontSize(action) {
    const articleBody = document.querySelector('.article-body');
    if (articleBody) {
        if (action === 'increase' && currentFontSize < 28) {
            currentFontSize += 2;
        } else if (action === 'decrease' && currentFontSize > 15) {
            currentFontSize -= 2;
        }
        articleBody.style.fontSize = currentFontSize + 'px';
    }
}
