from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('dhamma_app.urls')), # dhamma_app ၏ လမ်းကြောင်းနှင့် ချိတ်ဆက်ခြင်း
]
